/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan18_kelipatan;

/**
 *
 * Nama : DESIS FIRMANSYAH
* Kelas : PBO ulang 3
* NIM   : 10116075
 * Deskripsi program  : program ini berisi program untuk menampilkan 
 * bilangan kelipatan kelipatan 3,5 dimulai daro 3,5 sampai 35
 */
public class PBO3_10116075_Latihan18_Kelipatan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(double i = 3.5; i <= 35; i += 3.5){
            System.out.println( i + " ");
        }
    }
    
}
